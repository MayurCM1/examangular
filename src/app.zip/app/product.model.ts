export class Product{
 pid:number;
 pname:string;
 price:number;
 constructor(pid:number,pname:string,price:number){
     this.pid=pid;
     this.pname=pname;
     this.price=price;
 }

}